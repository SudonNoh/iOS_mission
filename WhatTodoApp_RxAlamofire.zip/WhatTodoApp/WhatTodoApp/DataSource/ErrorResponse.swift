//
//  ErrorResponse.swift
//  WhatTodoApp
//
//  Created by Sudon Noh on 2023/05/27.
//

import Foundation

// MARK: - ErrorResponse
struct ErrorResponse: Codable {
    let message: String?
}
