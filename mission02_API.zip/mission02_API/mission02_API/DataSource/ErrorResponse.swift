import Foundation

// MARK: - ErrorResponse
struct ErrorResponse: Codable {
    let message: String?
}
