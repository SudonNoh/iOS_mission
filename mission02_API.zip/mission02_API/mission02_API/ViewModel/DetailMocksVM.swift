//
//  Mocks.swift
//  mission02_API
//
//  Created by Sudon Noh on 2023/05/20.
//

import Foundation
import RxSwift
import RxRelay


class DetailMocksVM {
    
    var disposeBag = DisposeBag()
    
    var mock : BehaviorRelay<Mock?> = BehaviorRelay<Mock?>(value:nil)
    var errorMsg : BehaviorRelay<String> = BehaviorRelay<String>(value: "")
    
    //MARK: - 질문 7. 이런식으로 불러오는 것이 맞는지?
    init(id: String = "1") {
        fetchAMock(id: id)
    }
    
    /// 특정 id 보기
    //MARK: - 질문 5. 다른 뷰 컨트롤러면 뷰 모델도 따로 만들어야 하는지?, 만약 같은 뷰 모델을 사용한다면 init() 은 어떻게 해결하는지?
    func fetchAMock(id: String = "1") {
        MocksAPI.fetchAMockAPI(id: id)
            .withUnretained(self)
            .do(onError: { Error in
                self.errorMsg.accept(self.errorHandler(Error))
            })
            .subscribe(onNext: { response in
                //MARK: - 질문 6. 여기서는 vm / data 로 나오는 이유?
                self.mock.accept(response.1.data)
            })
            .disposed(by: disposeBag)
    }
    
    /// Error Handler
    fileprivate func errorHandler(_ err: Error) -> String {
        guard let apiError = err as? MocksAPI.APIError else {
            return ""
        }
        
        return apiError.info
    }
}
